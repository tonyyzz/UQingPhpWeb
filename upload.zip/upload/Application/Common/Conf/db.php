<?php
return array (
'DB_TYPE'=> 'mysql',
'DB_HOST'=> '127.0.0.1',
'DB_NAME'=> '',
'DB_USER'=> '',
'DB_PWD'=> '',
'DB_PORT'=> '3306',
'DB_PREFIX'=> 'qs_',
'DB_CHARSET'=> 'utf8'
);