<?php 
return array(
	'hrtools_null_error_h_typeid'=> '分类不能为空！',
	'hrtools_null_error_h_filename'=> '文档名称不能为空！', 
	'hrtools_null_error_h_fileurl'=> '上传文件不能为空！', 
	'hrtools_enum_error_h_typeid'=> '请正确选择分类！',
	'hrtools_enum_error_h_order'=> '请正确填写排序信息！', 
	'hrtools_enum_error_h_strong'=> '请正确选择字体样式！',
	'h_filename_length' => '文档名称长度应在1~100个字之间！',
)		
?>