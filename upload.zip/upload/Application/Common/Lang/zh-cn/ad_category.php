<?php
	return array(
		'ad_category_null_error_categoryname' => '广告分类名称不能为空！',
		'ad_category_null_error_alias' => '调用名不能为空！',
		'ad_category_null_error_type_id' => '请选择广告类型！',

		'ad_category_enum_error_type_id' => '请正确选择广告类型！',
		'ad_category_length_error_alias' => '调用名应在1~40个字内！',
	);
?>