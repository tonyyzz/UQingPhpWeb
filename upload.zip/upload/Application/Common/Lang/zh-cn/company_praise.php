<?php 
return array(
		/*
		**为空提示
		*/

		'company_praise_null_error_uid' => 'UID不能为空！', 
		'company_praise_null_error_company_id' => '公司ID不能为空！', 
		'company_praise_null_error_click_type' => '操作类型不能为空！', 
		/*
		**数字提示
		*/
		'company_praise_enum_error_uid' => '请填写正确的UID！', 
		'company_praise_enum_error_company_id' => '请填写正确的公司ID！',
		'company_praise_enum_error_click_type' => '请填写正确的操作类型！',//操作类型(1->访问 2->点赞 3->分享) 
)
?>