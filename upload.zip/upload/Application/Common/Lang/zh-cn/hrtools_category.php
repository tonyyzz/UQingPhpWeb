<?php 
return array(
		'hrtools_category_null_error_c_name'=> '分类名称不能为空！', 
		'hrtools_category_length_error_c_name' => '分类名称长度应在1~30个字之间！',
		'hrtools_category_unique_c_name' => '分类名称已经存在！'
)		
?>