<?php
	return array(
		'article_category_null_error_categoryname' => '新闻分类名称不能为空！',
		'article_category_length_error_categoryname' => '新闻分类名称应在1~40个字内！',
	);
?>