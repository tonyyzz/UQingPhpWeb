<?php
	return array(
		'admin_log_null_error_admin_name' => '管理员名称不能为空！',
		'admin_log_null_error_log_value' => '管理员日志不能为空！',
	);
?>