<?php
	return array(
		/*
			唯一提示
		*/
		'category_district_exist_error_spell' => '别名已经存在！',
		/*
			长度提示	
		*/
		'category_jobs_length_error_categoryname' => '分类名称应在1~40个字内！',
	);
?>