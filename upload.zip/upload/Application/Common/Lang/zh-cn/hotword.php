<?php 
return array(
		/*
		**为空提示
		*/
		'hotword_null_error_w_word'=> '关键字不能为空！',
		'hotword_length_error_w_word'=> '关键字应为1~60个字内！',
)		
?>