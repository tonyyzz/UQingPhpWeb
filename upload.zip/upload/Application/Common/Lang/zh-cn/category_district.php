<?php
	return array(
		'category_district_length_error_categoryname' => '地区分类名称应在1~30个字之间！',
		/*
			唯一提示
		*/
		'category_district_exist_error_spell' => '别名已经存在！',
	);
?>