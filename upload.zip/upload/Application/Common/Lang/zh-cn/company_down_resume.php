<?php 
return array(
		/*
		**为空提示
		*/
		'company_down_resume_null_error_resume_id' => '简历id不能为空！', //简历id
		'company_down_resume_null_error_resume_name' => '简历名称不能为空！', //简历名称
		'company_down_resume_null_error_resume_uid' => '简历uid不能为空！', //简历uid
		'company_down_resume_null_error_company_uid' => '公司uid不能为空！', //猎头uid
		'company_down_resume_null_error_company_name' => '公司名称不能为空！', //猎头名称
		/*
		**数字提示
		*/
		'company_down_resume_enum_error_resume_id' => '请填写正确的简历id！', //简历id
		'company_down_resume_enum_error_resume_uid' => '请填写正确的简历uid！', //简历uid
		'company_down_resume_enum_error_company_uid' => '请填写正确的公司uid！', //猎头uid
)
?>