<?php 
return array(
		/*
		**为空提示
		*/
		'explain_null_error_type_id'=> '请选择说明页类型！', 
		'explain_null_error_title'=> '说明标题不能为空！', 
		'explain_null_error_content'=> '说明内容不能为空', 
)		
?>